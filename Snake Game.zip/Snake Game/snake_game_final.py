from turtle import Screen, Turtle
from snake import Snake 
from food import Food
from scoreboard import Scoreboard
import time

screen = Screen() #create instance of the object 
screen.setup(width=600,height=600) #method function of the screen, setting width and height as arguments
screen.bgcolor("black")
screen.title("My Snake Game")
screen.tracer(0)

snake = Snake()
food = Food()
scoreboard = Scoreboard()

screen.listen()
screen.onkey(snake.up,"Up")
screen.onkey(snake.down,"Down")
screen.onkey(snake.left,"Left")
screen.onkey(snake.right,"Right")

#starting_positions = [(0, 0), (-20, 0), (-40, 0)]


#segments = []


#for position in starting_positions:
   # new_segment = Turtle("square") #new variable to create the object and set square method to change shape
    #new_segment.color("white")
    #new_segment.penup()
   # new_segment.goto(position) #iterates through the tuples
   # segments.append(new_segment)



game_is_on = True
while game_is_on:
    screen.update() #update here moves all pieces at once, looks like snake
    time.sleep(0.1)
    
    snake.move()
   
        
    #detect collision with the food
    
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        scoreboard.increase_score()
        print(f"nom nom nom.your new score is {scoreboard.score}")
        #screen.update() if you put it here and remove the above update, it moves piece by piece
        #time.sleep(1)
    
    #detect wall collision
    
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        game_is_on = False
        scoreboard.game_over()
        
    #detect collision with tail
    
    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 10:
            game_is_on = False
            scoreboard.game_over()
       
       # if segment == snake.head:
            #pass


screen.exitonclick()